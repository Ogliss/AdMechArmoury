﻿using RimWorld;
using Verse;
using Harmony;
using System.Reflection;
using System.Collections.Generic;
using System;
using System.Linq;

namespace VanillaSecurityExpanded
{
    [StaticConstructorOnStartup]
    class Main
    {
        static Main()
        {
            var harmony = HarmonyInstance.Create("com.ogliss.rimworld.mod.VanillaArmorsExpanded");
            harmony.PatchAll(Assembly.GetExecutingAssembly());
        }
    }

}