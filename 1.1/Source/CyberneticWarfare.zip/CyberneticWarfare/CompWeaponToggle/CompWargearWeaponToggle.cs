﻿using System;
using System.Collections.Generic;
using RimWorld;
using Verse;

namespace CyberneticWarfare
{
    public class CompProperties_WargearWeaponToggle : CompProperties
    {
        public CompProperties_WargearWeaponToggle()
        {
            this.compClass = typeof(CompWargearWeaponToggle);
        }
        public ResearchProjectDef requiredResearch;
    }

    // Token: 0x02000002 RID: 2
    public class CompWargearWeaponToggle : CompWargearWeapon
    {
        public CompProperties_WargearWeaponToggle Props => (CompProperties_WargearWeaponToggle)props;

        //public ThingDef secondaryProjectile;


        public bool Toggled = false;
        // Determine who is wearing this ThingComp. Returns a Pawn or null.


        // Determine who is wearing this ThingComp. Returns a Pawn or null.

        protected virtual VerbProperties PrimaryProjectile
        {
            get
            {
                if (parent != null && parent is ThingWithComps)
                {
                    return parent.def.Verbs[1];
                }
                else
                {
                    return null;
                }
            }
        }


        // Determine who is wearing this ThingComp. Returns a Pawn or null.
        protected virtual VerbProperties SecondaryProjectile
        {
            get
            {
                if (parent != null && parent is ThingWithComps)
                {
                    return parent.def.Verbs[2];
                }
                else
                {
                    return null;
                }
            }
        }

        public override void PostSpawnSetup(bool respawningAfterLoad)
        {
            base.PostSpawnSetup(respawningAfterLoad);
        }


        public override IEnumerable<Gizmo> EquippedGizmos()
        {
            ThingWithComps owner = IsWorn ? GetWearer : parent;
            bool flag = Find.Selector.SingleSelectedThing == GetWearer;
            if (flag && GetWearer.Drafted)
            {
                int num = 700000101;
                Command_Action command_Action = new Command_Action();
                switch (this.fireMode)
                {
                    case CompWargearWeaponToggle.FireMode.Primary:
                        command_Action.icon = PrimaryProjectile.defaultProjectile.uiIcon; // ContentFinder<Texture2D>.Get("Ui/Commands/CommandButton_LigthModeForcedOn", true);
                        command_Action.defaultLabel = "Firemode: " + PrimaryProjectile.label;
                        break;
                    case CompWargearWeaponToggle.FireMode.Secondary:
                        command_Action.icon = SecondaryProjectile.defaultProjectile.uiIcon; // ContentFinder<Texture2D>.Get("Ui/Commands/CommandButton_LigthModeForcedOff", true);
                        command_Action.defaultLabel = "Firemode: " + SecondaryProjectile.label;
                        break;
                }
                command_Action.defaultDesc = "Switch mode.";
                command_Action.activateSound = SoundDef.Named("Click");
                command_Action.action = new Action(this.SwitchFireMode);
                command_Action.groupKey = num + 1;
                if (GetWearer.Faction != Faction.OfPlayer)
                {
                    command_Action.Disable("CannotOrderNonControlled".Translate());
                }
                else if (GetWearer.stances.curStance.StanceBusy)
                {
                    command_Action.Disable("Is Busy");
                }
                yield return command_Action;
                /*
                if (Toggled==false)
                {

                    Command_Action command_Action = new Command_Action();
                    command_Action.defaultLabel = parent.def.label;
                    command_Action.defaultDesc = "This switches the" + parent.def.label + "to its secondary firing mode";
                    command_Action.hotKey = KeyBindingDefOf.Misc2;
                    command_Action.icon = parent.def.uiIcon;
                    command_Action.disabled = false;
                    yield return command_Action;
                }
                else
                {

                    Command_Action command_Action = new Command_Action();
                    command_Action.defaultLabel = parent.def.label;
                    command_Action.defaultDesc = "This switches the" + parent.def.label + "to its primary firing mode";
                    command_Action.hotKey = KeyBindingDefOf.Misc2;
                    command_Action.icon = parent.def.uiIcon;
                    command_Action.disabled = false;
                    yield return command_Action;
                }
                */
            }
            yield break;
        }

        public override void CompTick()
        {
            base.CompTick();
            if (GetWearer != lastWearer)
            {
                lastWearer = GetWearer;
            }
        }

        // Token: 0x06000004 RID: 4 RVA: 0x000020EE File Offset: 0x000002EE
        public void RefreshFireState()
        {
            if (this.fireMode == CompWargearWeaponToggle.FireMode.Secondary)
            {
                //Log.Message(string.Format("secondary projectile selected:{0}", SecondaryProjectile.label));
                this.ToggleSecondaryFire();
                return;
            }
            //Log.Message(string.Format("priary projectile selected:{0}", PrimaryProjectile.label));
            this.TogglePrimaryFire();
        }

        // Token: 0x06000006 RID: 6 RVA: 0x000021F0 File Offset: 0x000003F0
        public void ToggleSecondaryFire()
        {
            CompEquippable c = parent.GetComp<CompEquippable>();
            c.VerbTracker.PrimaryVerb.verbProps = SecondaryProjectile;
            this.Toggled = true;
            //Log.Message(string.Format("default projectile selected:{0}", c.VerbTracker.PrimaryVerb.verbProps.defaultProjectile.label));
        }

        // Token: 0x06000007 RID: 7 RVA: 0x0000227D File Offset: 0x0000047D
        public void TogglePrimaryFire()
        {
            CompEquippable c = parent.GetComp<CompEquippable>();
            c.VerbTracker.PrimaryVerb.verbProps = PrimaryProjectile;
            this.Toggled = false;
            //Log.Message(string.Format("default projectile selected:{0}", c.VerbTracker.PrimaryVerb.verbProps.defaultProjectile.label));
        }

        public void SwitchFireMode()
        {
            switch (this.fireMode)
            {
                case CompWargearWeaponToggle.FireMode.Secondary:
                    this.fireMode = CompWargearWeaponToggle.FireMode.Primary;
                    break;
                case CompWargearWeaponToggle.FireMode.Primary:
                    this.fireMode = CompWargearWeaponToggle.FireMode.Secondary;
                    break;
            }
            this.RefreshFireState();
        }
        // Token: 0x04000005 RID: 5
        public CompWargearWeaponToggle.FireMode fireMode;

        // Token: 0x02000004 RID: 4
        public enum FireMode
        {
            Primary,
            Secondary,
            Tertiary,
            Quaternary,
            Quinary,
            Senary,
            Septenary,
            Octonary,
            Nonary,
            Denary
        }
    }
}
