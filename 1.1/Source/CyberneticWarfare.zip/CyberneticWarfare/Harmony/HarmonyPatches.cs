﻿using System.Collections.Generic;
using System.Linq;
using Harmony;
using RimWorld;
using Verse;

namespace CyberneticWarfare
{
    [StaticConstructorOnStartup]
    internal static class HarmonyCompWargearWeapon
    {
        static HarmonyCompWargearWeapon()
        {
            var harmony = HarmonyInstance.Create("rimworld.ogliss.CyberneticWarfare.wargearweapon");

            var type = typeof(HarmonyCompWargearWeapon);
            harmony.Patch(AccessTools.Method(typeof(Pawn), nameof(Pawn.GetGizmos)), null,
                new HarmonyMethod(type, nameof(GetGizmos_PostFix)));
        }

        public static IEnumerable<Gizmo> GizmoGetter(CompWargearWeapon CompWargearWeapon)
        {
            if (CompWargearWeapon.GizmosOnEquip)
            {
                var enumerator = CompWargearWeapon.EquippedGizmos().GetEnumerator();
                while (enumerator.MoveNext())
                {
                    var current = enumerator.Current;
                    yield return current;
                }
            }
        }

        public static void GetGizmos_PostFix(Pawn __instance, ref IEnumerable<Gizmo> __result)
        {
            var pawn_EquipmentTracker = __instance.equipment;
            if (pawn_EquipmentTracker != null)
            {
                var thingWithComps = pawn_EquipmentTracker.Primary;
                if (thingWithComps != null)
                {
                    var CompWargearWeapon = thingWithComps.GetComp<CompWargearWeapon>();
                    if (CompWargearWeapon != null)
                        if (GizmoGetter(CompWargearWeapon).Count() > 0)
                            if (__instance != null)
                                if (__instance.Faction == Faction.OfPlayer)
                                    __result = __result.Concat(GizmoGetter(CompWargearWeapon));
                }
            }
        }
    }
}