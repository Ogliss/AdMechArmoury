﻿using RimWorld;
using System.Linq;
using Verse;

namespace CyberneticWarfare
{
    public class VerbPropertiesCW : VerbProperties
    {
        public bool rapidfire = false;
        public int pelletCount = 1;
    }

    public class Verb_ShootCW : Verb_LaunchProjectile
    {
        public VerbPropertiesCW VerbProps
        {
            get
            {
                return verbProps as VerbPropertiesCW;
            }
        }
   
        protected override int ShotsPerBurst
        {
            get
            {
                if (VerbProps.rapidfire == true && caster.Position.InHorDistOf(this.currentTarget.Cell, this.verbProps.range / 2))
                {
                    return this.verbProps.burstShotCount*2;
                }
                else
                {
                    return this.verbProps.burstShotCount;
                }
            }
        }

        public override void WarmupComplete()
        {
            base.WarmupComplete();
            if (base.CasterIsPawn && base.CasterPawn.skills != null)
            {
                float xp = 6f;
                if (this.currentTarget.Thing != null && this.currentTarget.Thing.def.category == ThingCategory.Pawn)
                {
                    if (this.currentTarget.Thing.HostileTo(this.caster))
                    {
                        xp = 240f;
                    }
                    else
                    {
                        xp = 50f;
                    }
                }
                base.CasterPawn.skills.Learn(SkillDefOf.Shooting, xp);
            }
        }

        protected override bool TryCastShot()
        {
            bool flag = base.TryCastShot();
            if (flag && base.CasterIsPawn)
            {
                base.CasterPawn.records.Increment(RecordDefOf.ShotsFired);

            }
            bool flag2 = flag && VerbProps.pelletCount - 1 > 0;
            bool flag3 = flag2;
            if (flag3)
            {
                for (int i = 0; i < VerbProps.pelletCount - 1; i++)
                {
                    base.TryCastShot();
                }
            }
            return flag;
        }
    }
}
