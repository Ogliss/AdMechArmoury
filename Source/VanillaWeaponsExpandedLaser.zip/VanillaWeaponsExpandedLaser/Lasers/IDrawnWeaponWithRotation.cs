﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VanillaWeaponsExpandedLaser
{
    interface IDrawnWeaponWithRotation
    {
        float RotationOffset
        {
            get;
            set;
        }
    }
}
