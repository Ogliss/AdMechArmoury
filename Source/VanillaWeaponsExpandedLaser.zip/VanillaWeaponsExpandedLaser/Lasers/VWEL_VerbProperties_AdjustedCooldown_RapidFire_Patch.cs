﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using Harmony;
using System.Reflection;
using UnityEngine;

namespace VanillaWeaponsExpandedLaser.Harmony
{
    /*
    [HarmonyPatch(typeof(VerbProperties), "AdjustedCooldown", new[] { typeof(Verb), typeof(Pawn) })]
    public static class VWEL_VerbProperties_AdjustedCooldown_RapidFire_Patch
    { 
        [HarmonyPostfix]
        public static void AdjustedCooldown_RapidFire_Postfix(ref Verb_Shoot __instance, Verb ownerVerb, Pawn attacker, ref float __result)
        {
            if (ownerVerb != null)
            {
                if (ownerVerb.EquipmentSource!=null)
                {

                    if (ownerVerb.EquipmentSource.GetComp<CompLaserCapacitor>() != null)
                    {
                        if (ownerVerb.EquipmentSource.GetComp<CompLaserCapacitor>() is CompLaserCapacitor GunExt)
                        {
                            CompEquippable eq = ownerVerb.EquipmentSource.TryGetComp<CompEquippable>();
                            Pawn pawn = ownerVerb.CasterPawn;
                            IntVec3 lastpos = (IntVec3)GunExt.lastFiringLocation;
                            if (lastpos == pawn.Position)
                            {
                                __result = Math.Max(__result - (GunExt.Props.WarmUpReductionPerShot * GunExt.shotstack), 0);
                            }
                        }
                    }
                }
            }
        }
    }
    */
}