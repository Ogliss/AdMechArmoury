﻿using Verse;

namespace VanillaWeaponsExpandedLaser
{
    public class Building_LaserGunDef : ThingDef
    {
        public int beamPowerConsumption = 20;
        public bool supportsColors = false;
    }
}
