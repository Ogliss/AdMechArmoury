﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VanillaWeaponsExpandedLaser
{
    public interface IBeamColorThing
    {
        int BeamColor
        {
            get;
            set;
        }
    }
}
